# 🇮🇳 India Live Market Terminal

A Bloomberg-style live market dashboard for 40 Indian stocks (NSE/BSE).
Built with React + Vite. Simulated live prices — swap in real API for production.

---

## ⚡ QUICK START (3 steps)

### Prerequisites
- Node.js 18+ → Download from https://nodejs.org

### Step 1 — Install dependencies
```bash
npm install
```

### Step 2 — Start dev server
```bash
npm run dev
```

### Step 3 — Open browser
```
http://localhost:3000
```

That's it! The dashboard opens automatically.

---

## 📁 PROJECT STRUCTURE

```
india-terminal/
├── index.html          ← HTML entry point
├── vite.config.js      ← Vite configuration
├── package.json        ← Dependencies
└── src/
    ├── main.jsx        ← React root mount
    └── App.jsx         ← ENTIRE dashboard (single file)
```

---

## 🔌 CONNECTING REAL NSE DATA

Replace the `useLivePrices` hook in App.jsx with real API calls.

### Option A — Zerodha Kite (Most popular)
```bash
npm install kiteconnect
```
```javascript
import { KiteConnect } from "kiteconnect";
const kite = new KiteConnect({ api_key: "YOUR_API_KEY" });

async function fetchQuotes(tickers) {
  const symbols = tickers.map(t => `NSE:${t}`);
  const quotes = await kite.getQuote(symbols);
  return Object.entries(quotes).map(([sym, q]) => ({
    ticker: sym.replace("NSE:", ""),
    price: q.last_price,
    change: q.change,
    volume: q.volume,
    high52: q.ohlc?.high || 0,
    low52: q.ohlc?.low || 0,
  }));
}
```
Sign up: https://kite.zerodha.com/connect/login

### Option B — Upstox API (Free tier available)
```bash
npm install upstox-js-sdk
```
Sign up: https://developer.upstox.com

### Option C — Angel One SmartAPI (Free)
```bash
npm install smartapi-javascript
```
Sign up: https://smartapi.angelbroking.com

### Option D — Yahoo Finance (No auth needed, 15-min delay)
```bash
npm install yahoo-finance2
```
```javascript
import yahooFinance from 'yahoo-finance2';

async function fetchQuote(ticker) {
  // NSE tickers use .NS suffix on Yahoo Finance
  const quote = await yahooFinance.quote(`${ticker}.NS`);
  return {
    price: quote.regularMarketPrice,
    change: quote.regularMarketChangePercent,
    volume: quote.regularMarketVolume,
    high52: quote.fiftyTwoWeekHigh,
    low52: quote.fiftyTwoWeekLow,
    marketCap: quote.marketCap,
    pe: quote.trailingPE,
  };
}
```

---

## 🚀 DEPLOY TO PRODUCTION

### Vercel (Recommended — Free)
```bash
npm install -g vercel
npm run build
vercel --prod
```

### Netlify
```bash
npm run build
# Drag & drop the 'dist' folder to netlify.com/drop
```

### Self-host (nginx/Apache)
```bash
npm run build
# Upload the 'dist' folder to your server
```

---

## 🛠️ CUSTOMIZATION

### Add/remove stocks
Edit the `STOCKS` array in `src/App.jsx`

### Change refresh rate
Find `setInterval(... 1100)` in `useLivePrices` and change 1100 to desired ms

### Add new columns
1. Add data field to STOCKS array
2. Add `<TH>` or `<THPlain>` in thead
3. Add `<td>` in tbody row

---

## 📊 FEATURES

- ✅ Live simulated prices with flash animations
- ✅ 40 stocks — 20 LT Conviction + 20 Daily Trading
- ✅ Sparkline mini charts (30-point rolling history)
- ✅ RSI bars with color coding
- ✅ 52-week position bar (rainbow gradient)
- ✅ Relative volume highlighting
- ✅ Sortable columns (click header)
- ✅ Tab filters (All / Conviction / Trading)
- ✅ Live search
- ✅ Pause/Resume data feed
- ✅ Bloomberg terminal dark aesthetic
- ✅ Fully responsive horizontal scroll

---

## ⚠️ DISCLAIMER

This dashboard uses simulated prices for demonstration.
Not financial advice. Consult a SEBI-registered advisor before investing.
